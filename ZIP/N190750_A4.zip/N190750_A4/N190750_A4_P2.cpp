/* 	 Name = N.Mariya Babu 
	ID = N190750
	Date = 18 july 2022
	Queue implementation using Array */
#include<stdio.h>
#include<stdlib.h>
#define N 20
//Queue definition
int queue[N];
int rare=-1,front=-1;
//Function to insert the element into the queue
int enqueue(int x){
	if(front==-1 && rare==-1){
		front=rare=0;
		queue[rare] = x;
	}
	else if(rare==N-1){
		printf("Overflow..");
	}
	else{
		queue[++rare] = x;
	}
	return 0;
}
//Function to delete the element from the queue
int dqueue(){
	int item = queue[front];
	if(front==-1 && rare==-1){
		printf("UnderFlow..");
		return -1;
	}
	else if(front==rare){
		front=rare=-1;
		return item;
	}else{
		front++;
		return item;
	}
	
}
//Function to display the content of the queue
int display(){
	int i;
	for(i=front;i<=rare;i++){
		printf("%d\t",queue[i]);
	}
	return 0;
}
//Main Function
int main(){
	int opt,data;
	while(1){
		printf("\n1.enqueue \n2.dequeue \n3.exit");
		printf("Choose your option :");
		scanf("%d",&opt);
		if(opt==1){
			printf("Enter the data into the queue :");
			scanf("%d",&data);
			enqueue(data);
		}
		else if(opt==2){
			printf("The deleted element is %d \n",dqueue());
		}
		else if(opt==3){
			exit(1);
		}
		else{
			printf("Invalid...");
		}
		display();	
	}
}
