/* 	 Name = N.Mariya Babu 
	ID = N190750
	Date = 18 july 2022
	C Programme to implement the DoubleEnded Queue */
#include<stdio.h>
#include<stdlib.h>
#define N 5
//Queue definition
int queue[N];
int front=-1,rare=-1;
//Function the Enqueue from the front of the queue
int EnqueueFront(int x = 10){
	if(front==-1 && rare==-1){
		front=rare=0;
		queue[front] = x;
	}
	else if(front==0){
		if(rare==N-1){
			printf("OverFlow");
		}
		else{
			front=N-1;
			queue[front] = x;
		}
	}
	else {
		if(((front-1)%N)==rare){
			printf("OverFlow");
		}
		else{
			front = (front-1)%N;
			queue[front] = x;
		}
	}
}
//Function to Enqueue from the tail/rare of the queue
int EnqueueRare(int x = 5){
	if(front==-1 && rare==-1){
		rare = front = 0;
		queue[rare] = x;
	}
	else if((rare+1)%N==front){
		printf("Overflow..");
	}
	else{
		rare = (rare+1)%N;
		queue[rare] = x;
	}
	return 0;
}
//Function to dequeue the element from the front of the queueu
int DequeueFront(){
	int item;
	item = queue[front];
	if(front==-1 && rare==-1){
		printf("Under Flow...");
	}
	else if(front==rare){
		printf("\nThe Dequeued item is : %d  ",item);
		front=rare=-1;
		return item;
	}
	else{
		front = (front+1)%N;
		printf("\nThe Dequeued item is %d : \n",item);
		return item;
	}
}
//Function to dequeue the element from the tail/rare of the queue
int DequeueRare(){
	int item;
	item = queue[rare];
	if(front==-1 && rare==-1){
		printf("UnderFlow...");
	}
	else if(front==rare){
		front=rare=-1;
		printf("\nThe Dequeued item is %d : \n",item);
		return item;
		
	}
	else if(rare==0){
		rare = N-1;
		printf("\nThe Dequeued item is %d : \n",item);
		return item;
	}
	else{
		rare = (rare-1)%N;
		printf("\nThe Dequeued item is %d : \n",item);
		return item;
	}
	
}
//Function to display the content of the queue
int display(){
	int i;
	i = front;
	while(i!=rare){
		printf("%d\t",queue[i]);
		i = (i+1)%N;
	}
	return 0;
}
//Main Function
int main(){
	int opt,data;
	printf("Exprense the double ended queue data structure...");
	while(1){
		printf("\n1.EnqueueFront \n2.EnqueueRare \n3.DequeueFront \n4.DequeueRare \n5.exit ");
		printf("Enter your option :");
		scanf("%d",&opt);
		if(opt==1){
			printf("Enter the data to insert the data front of the queue :");
			scanf("%d",&data);
			EnqueueFront(data);
		}
		else if(opt==2){
			printf("Enter the data to insert the data rare of the queue :");
			scanf("%d",&data);
			EnqueueRare(data);
		}
		else{
			switch(opt){
				case 3:
					DequeueFront();
					break;
				case 4:
					DequeueRare();
					break;
				case 5:
					exit(1);
				default:
					printf("Invalid option...");
						
			}
		}
		display();
	}
}
