/* 	 Name = N.Mariya Babu 
	ID = N190750
	Date = 18 july 2022 
	C Programme to implement the queue using the linked list */
#include<stdio.h>
#include<stdlib.h>
//Structure definition
struct queue{
	int data;
	struct queue *next;
}*head=NULL,*tail=NULL,*nn,*ptr;
//Function to implemention enqueue operation
int enqueue(){
	nn = (struct queue*) malloc (sizeof(struct queue));
	printf("Enter the node data :");
	scanf("%d",&nn->data);
	if(head==NULL && tail==NULL){
		head=tail=nn;
		nn->next = NULL;
	}
	else{
		tail->next=nn;
		tail=nn;
		nn->next = NULL;
	}
}
//Function to implement the dqueue operation
int dqueue(){
	int item = head->data;
	if(head==tail){
		head=tail=NULL;
		return item;
	}
	else{
		ptr = head;
		head=head->next;
		return item;
	}
	
}
//Function to display the queue element's
int display(){
	ptr = head;
	while(ptr!=NULL){
		printf("%d\t",ptr->data);
		ptr = ptr->next;
	}
	return 0;
}
//Main Function
int main(){
	int opt;
	printf("Queue implimintation using linked list...");
	while(1){
		printf("\n1.enqueue \n2.dqueue \n3.exit ");
		printf("\nEnter your option :");
		scanf("%d",&opt);
		switch(opt){
			case 1:
				enqueue();
				break;
			case 2:
				dqueue();
				break;
			case 3:
				exit(1);
			default:
				printf("Invalid Option....");
		}
		display();
	}
	return 0;
}
