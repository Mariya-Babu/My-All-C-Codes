/* 
	Name :- N.Mariya Babu
	Date :- 8/23/2022
	ID:- N190750
*/
//C Programme to find all the Nth level nodes 
//HeaderFiles section
#include <stdio.h>
#include <stdlib.h>
//Structure Definition 
struct btnode
{
    int value;
    struct btnode *l;
    struct btnode *r;
}*root = NULL, *temp = NULL, *t2, *t1; 
//Function Declaration section 
void insert();
void inorder(struct btnode *t);
void create();
void level(struct btnode *t,int plevel,int l);
void search(struct btnode *t);
//Main Function 
void main()
{
    int i,x,l;
	printf("enter the level number:");
	scanf("%d",&l);
    printf("enter the number of nodes:");
    scanf("%d",&x);
    for(i=0;i<x;i++)
    {
    	insert();
    }
    level(root,0,l);
}
// Function to insert the data into the BST 
void insert()
{
    create();
    if (root == NULL) 
        root = temp;
    else    
        search(root);    
} 
/* To create a node */
void create()
{
    int data;
    printf("Enter data of node to be inserted : ");
    scanf("%d", &data);
    temp = (struct btnode *)malloc(1*sizeof(struct btnode));
    temp->value = data;
    temp->l = temp->r = NULL;
} 
/* Function to search the appropriate position to insert the new node */
void search(struct btnode *t)
{
    if ((temp->value > t->value) && (t->r != NULL))      /* value more than root node value insert at right */
        search(t->r);
    else if ((temp->value > t->value) && (t->r == NULL))
        t->r = temp;
    else if ((temp->value < t->value) && (t->l != NULL))    /* value less than root node value insert at left */
        search(t->l);
    else if ((temp->value < t->value) && (t->l == NULL))
        t->l = temp;
}
void level(struct btnode *t,int plevel,int l)
{
	
	if(t==NULL)
	{
		return;
	}
	if(plevel==l)
	{
		printf("%d ",t->value);
		return;
	}
	level(t->l,plevel+1, l);
	level(t->r,plevel+1,l);
}
