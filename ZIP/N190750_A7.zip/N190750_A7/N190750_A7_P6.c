/* 
	Name :- N.Mariya Babu
	Date :- 8/23/2022
	ID:- N190750
*/
//C Programme to find the nodes which are at max distance from the root in a BST 
//HeaderFiles section
#include <stdio.h>
#include <stdlib.h>
//Structure definition 
struct btnode
{
    int value;
    struct btnode *l;
    struct btnode *r;
}*root = NULL, *temp = NULL, *t2, *t1; 
//Function definition section 
void insert();
void create();
void search(struct btnode *t);
void max(struct btnode *t);
int c=0,m=0,v[50],j=0,a[50],ma;
//main Function 
void main()
{
    int i,x;;
    printf("enter the number of nodes:");
    scanf("%d",&x);
    for(i=0;i<x;i++)
    {
    	insert();
    }
    m=0;c=0;
    max(root);
    for(i=0;i<j;i++)
    {
    	ma=a[0];
    	if(ma<a[i])
           ma=a[i];
	}
	printf("maximum distance node:");
	for(i=0;i<j;i++)
	{
		if(ma==a[i])
		  printf("%d ,%d ",v[i],ma);
	}
}
//Function to insert the data into the BST 
void insert()
{
    create();
    if (root == NULL) 
        root = temp;
    else    
        search(root);    
} 
/* To create a node */
void create()
{
    int data;
    printf("Enter data of node to be inserted : ");
    scanf("%d", &data);
    temp = (struct btnode *)malloc(1*sizeof(struct btnode));
    temp->value = data;
    temp->l = temp->r = NULL;
} 
/* Function to search the appropriate position to insert the new node */
void search(struct btnode *t)
{
    if ((temp->value > t->value) && (t->r != NULL))      /* value more than root node value insert at right */
        search(t->r);
    else if ((temp->value > t->value) && (t->r == NULL))
        t->r = temp;
    else if ((temp->value < t->value) && (t->l != NULL))    /* value less than root node value insert at left */
        search(t->l);
    else if ((temp->value < t->value) && (t->l == NULL))
        t->l = temp;
}
//Function to find the maximum value in the BST 
void max(struct btnode *t)
{
	if(t->l!=NULL)
	{
		c++;
		max(t->l);
	}
	if(m<c)
	  m=c;
	if(m==c)
	{
		a[j]=m;
		v[j]=t->value;
		j++;
	}
	if(t->r!=NULL)
	{
		c++;
		max(t->r);
	}
	c--;
}
