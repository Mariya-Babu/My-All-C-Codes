/* Name = N.Mariya Babu 
   ID = N190750
   Date = 12 july 2022
This programme is to perform the basic operation's push,pop,disply,peek using the Stack DataStructure throught linked list*/

//Header file's section
#include<stdio.h>
#include<stdlib.h>
//Structure Definition section
struct stack{
	int data;
	struct stack *next;
}*head=NULL,*ptr,*qtr,*nn,*top,*temp=NULL;
//Function declaration section
int push(void);
int pop(void);
int peek(void);
int display(void);
//Main function
int main(){
	while(1){
		int n;
		printf("\n1 push \n2 pop \n3 peek element \n4 exit\n");
		printf("Enter your option :");
		scanf("%d",&n);
		switch(n){
			case 1:
				push();
				break;
			case 2:
				pop();
				break;
			case 3:
				peek();
				break;
			case 4:
				exit(1);
				break;
			default:
				printf("Invalid Syntax");
		}
		display();
	}
	return 0;
}
//Function to read the element's
int push(){
	int i=1;
	while(i){
		nn = (struct stack *)malloc(sizeof(struct stack));
		printf("Enter the data :");
		scanf("%d",&nn->data);
		nn->next = NULL;
		//top = nn;
		if(head==NULL){
			head = nn;
			top = nn;
		}else{
			ptr = top;
			top = nn;
			top->next = ptr;
		}
		printf("Press 0 to exit otherwise enter any number for push operation :");
		scanf("%d",&i);
	}
	return 0;
}
//Function to pop the top element
int pop(){
	int item;
	item = top->data;
	temp = top;
	top = top->next;
	free(temp);
	printf("The poped item is %d\n",item);
	return item;
}
//Function to display the peek element
int peek(){
	printf("The peek element is %d\n ",top->data);
	return top->data;
}
//Function to dispay the element's in the stack
int display(){
	temp = top;
	while(temp!=NULL){
		printf("%d\t",temp->data);
		temp = temp->next;
	}
	return 0;
}
